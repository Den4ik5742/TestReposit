minesweeper.js
==============

Minesweeper game implementation in HTML, CSS and Javascript
